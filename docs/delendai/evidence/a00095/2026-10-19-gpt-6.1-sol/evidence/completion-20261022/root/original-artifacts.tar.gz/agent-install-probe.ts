import {createHash} from 'node:crypto';
import {mkdtemp,mkdir,writeFile,readFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join,relative} from 'node:path';
import {compactAgentRegistry} from '/home/cartago/_projects/delendai/.cache/delendai/.worktrees/gpt-6.1-sol-a00095-S6-g2/packages/core/src/lib/shared/agent-registry.service.ts';
import {installAgentBinary,agentInstallDir} from '/home/cartago/_projects/delendai/.cache/delendai/.worktrees/gpt-6.1-sol-a00095-S6-g2/packages/core/src/lib/shared/declared-agents.service.ts';
const owned=await mkdtemp(join(tmpdir(),'delendai-owned-agent-install-'));const root=join(owned,'agents');await mkdir(root);
const bytes=new TextEncoder().encode('owned synthetic archive; unpack is an explicit port');const sha256=createHash('sha256').update(bytes).digest('hex');
const agent=(id:string)=>({id,name:'Fixture',version:'v1',distribution:{binary:{'linux-x86_64':{archive:'https://fixture.invalid/a.tar.gz',cmd:'fixture-agent',sha256}}}});
const exists=async(p:string)=>readFile(p,'utf8').then(()=>true,()=>false);
for(const [label,id,code] of [['normal-control','valid-agent',0],['escape-id','../sibling',0],['unpack-failure','valid-existing',1]] as const){
 const parsed=compactAgentRegistry({agents:[agent(id)]})!.agents[0]!;const dir=agentInstallDir(parsed,root);await mkdir(dir,{recursive:true});const sentinel=join(dir,'previous-owned-install.txt');await writeFile(sentinel,'owned prior installation');let result:any;
 try{result=await installAgentBinary(parsed,{root,platform:'linux-x86_64',download:async()=>bytes,run:async()=>({code,output:code===0?'':'synthetic unpack failure'})})}catch(e){result={error:String(e)}}
 console.log(JSON.stringify({case:label,parsedId:parsed.id,targetRelativeToInstallRoot:relative(root,dir),insideOwnedFixture:relative(owned,dir),priorInstallRetained:await exists(sentinel),result}));
}
const safe=agent('hash-control');const d=agentInstallDir(safe,root);await mkdir(d,{recursive:true});const sentinel=join(d,'previous-owned-install.txt');await writeFile(sentinel,'preserve-on-bad-hash');let rejected=false;try{await installAgentBinary(safe,{root,platform:'linux-x86_64',download:async()=>new Uint8Array([9]),run:async()=>{throw Error('must not unpack bad hash')}})}catch{rejected=true}console.log(JSON.stringify({case:'hash-rejection-control',rejected,priorInstallRetained:await exists(sentinel)}));
console.log(JSON.stringify({limits:'Every directory, including escape sibling, belongs to this fresh tmp fixture. Actual compact parser/install helper; injected download and unpack. No shell, network, executable or real installation.',owned}));
