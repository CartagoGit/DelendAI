import { Database } from 'bun:sqlite';
import { strict as assert } from 'node:assert';
import { GenerationsRepo } from '../test-snapshot/packages/proposals-sqlite/src/lib/work-model/generations-repo';
import { runForgePhase } from '../test-snapshot/packages/core/src/lib/startup-reconciler/phases/reconcile-forge';
const table=`CREATE TABLE generations(id INTEGER PRIMARY KEY,work_unit_id INTEGER,generation INTEGER,base_integration_sha TEXT,wip_ref TEXT,wip_head_sha TEXT,patch_digest TEXT,file_scope_json TEXT,file_scope_digest TEXT,checkpoint_kind TEXT,candidate_state TEXT,validation_state TEXT,author_agent_id TEXT,machine_id TEXT,pull_request_id INTEGER,ci_result TEXT,integrated_sha TEXT,revision INTEGER,updated_at INTEGER)`;
const rebuilt={workUnitId:1,generation:2,ref:'refs/wip/maker/fixture-s1-g2',sha:'new-sha',workUnitUid:'fixture-unit'};
for(const states of [['failure','success'],['success','failure']]){
 const db=new Database(':memory:');db.exec(table);db.query(`INSERT INTO generations VALUES(1,1,2,'base','${rebuilt.ref}','new-sha','digest','[]','files','merge-candidate','pending','unknown','maker','fixture',NULL,NULL,NULL,1,0)`).run();const generations=new GenerationsRepo(db);
 await runForgePhase({forge:{listPullRequests:async()=>({kind:'payload',payload:[]}),listCheckRuns:async()=>({kind:'payload',payload:states.map((state,i)=>({candidateSha:rebuilt.sha,workflow:'fixture',checkName:'check-'+i,state}))})},ports:{forge:{upsertCiRun:()=>({id:1})},generations} as any,repositoryId:1,rebuilt:[rebuilt],previousEtag:'',machineId:'fixture',now:500});
 const row=generations.get(1,2)!;assert.equal(row.validationState,states.at(-1)==='success'?'green':'red');console.log(JSON.stringify({case:'real-sqlite-CI-'+states.join('-'),finalValidation:row.validationState,ciResult:row.ciResult}));db.close();
}
for(const matching of [false,true]){
 const db=new Database(':memory:');db.exec(table);db.query(`INSERT INTO generations VALUES(1,1,2,'base','${rebuilt.ref}','new-sha','digest','[]','files','merge-candidate','pending','unknown','maker','fixture',NULL,NULL,NULL,1,0)`).run();const generations=new GenerationsRepo(db);
 await runForgePhase({forge:{listPullRequests:async()=>({kind:'payload',payload:[{number:1,headRef:rebuilt.ref,headSha:matching?'new-sha':'older-sha',baseRef:'integration',state:'merged',mergeSha:'old-merge'}]}),listCheckRuns:async()=>({kind:'payload',payload:[]})},ports:{forge:{upsertPullRequest:()=>({id:1})},generations} as any,repositoryId:1,rebuilt:[rebuilt],previousEtag:'',machineId:'fixture',now:500});
 const row=generations.get(1,2)!;assert.equal(row.integratedSha,'old-merge');console.log(JSON.stringify({case:'real-sqlite-PR-'+(matching?'match':'mismatch'),wipHeadSha:row.wipHeadSha,integratedSha:row.integratedSha,candidateState:row.candidateState}));db.close();
}
