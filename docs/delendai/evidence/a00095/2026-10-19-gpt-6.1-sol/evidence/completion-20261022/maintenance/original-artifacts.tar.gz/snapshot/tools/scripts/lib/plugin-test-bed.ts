/**
 * plugin-test-bed.ts — Solid-DRY extraction shared between verify and
 * generate-tools scripts.
 *
 * Both scripts previously inlined the same dance:
 *
 *   1. Build `parseCliArgs([...], workspaceRoot)` with a single
 *      `--plugins=<name>` arg.
 *   2. Call `assembleCliConfig(args, deps)` with a custom `import`
 *      adapter (so the real plugin module is loaded without a
 *      network roundtrip — the verify script wraps it in
 *      `() => import('../../plugins/<name>/src/index.ts')`).
 *   3. Sometimes override `readFile` (the verify script ships a
 *      synthetic config; the generate script routes deps.allowNetwork).
 *
 * After this split:
 *
 *   - **DRY**: one implementation, two callers.
 *   - **DIP**: callers depend on `assemblePluginForTest`, not on
 *     `assembleCliConfig` directly. Tests can pass a stub
 *     `IImportAdapter` and assert the assembled config.
 *   - **OCP**: new test fixtures (different synthetic config files,
 *     different plugin resolvers) extend the options, not the script.
 */
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';

import { assembleCliConfig } from '@delendai/core/public';
import { parseCliArgs } from '@delendai/core/plugin';
import type { IAssembleCliDeps, IAssembledCliConfig } from '@delendai/core/cli';

/**
 * Solid-DIP: a tiny adapter that resolves a plugin SPECIFIER to its
 * default-exported plugin module. Production wires
 * `createLocalPluginImporter(workspaceRoot)` which loads
 * `plugins/<name>/src/index.ts` via dynamic import.
 *
 * Tests can pass any function `(specifier) => Promise<{default: ...}>`
 * — no path strings, no fs imports.
 */
export type IPluginImporter = (pluginName: string) => Promise<{
	default: unknown;
}>;

/**
 * The loader tries each of `@delendai/<name>`, `mcp-<name>`, `<name>`
 * (see core `load-plugins.ts`) — normalise any of them back to the
 * bare plugin directory name.
 */
const pluginDirNameFor = (specifier: string): string => {
	if (specifier.startsWith('@delendai/')) {
		return specifier.slice('@delendai/'.length);
	}
	if (specifier.startsWith('mcp-')) return specifier.slice('mcp-'.length);
	return specifier;
};

/**
 * Production importer: dynamic-imports
 * `<workspaceRoot>/plugins/<name>/src/index.ts`.
 *
 * x00105 S1 (the bug that made verify:tools lie): the previous
 * implementation IGNORED `workspaceRoot` and imported
 * `../../plugins/<specifier>/src/index.ts` — a relative path that
 * stopped resolving when this module was extracted into
 * `tools/scripts/lib/`, fed with npm specifiers instead of directory
 * names. Every plugin load failed, the errors were swallowed
 * downstream, and the "verified" tool list silently degraded to the
 * core tools. The importer now builds an ABSOLUTE file URL from the
 * workspace root and normalises the specifier.
 */
export const createLocalPluginImporter =
	(workspaceRoot: string): IPluginImporter =>
	(pluginName) =>
		import(
			pathToFileURL(
				join(
					workspaceRoot,
					'plugins',
					pluginDirNameFor(pluginName),
					'src/index.ts',
				),
			).href
		).then((mod) => ({
			default: mod.default,
		}));

/**
 * Optional override for `readFile` (the verify script ships a
 * synthetic config; the generate script routes deps.allowNetwork).
 * Default: no file (delendai.config.json not present).
 */
export interface IPluginTestBedOptions {
	readonly workspaceRoot: string;
	readonly pluginName: string;
	readonly importer?: IPluginImporter;
	/**
	 * When provided, the synthetic config payload. The `readFile`
	 * adapter returns this for every path ending in
	 * `delendai.config.json` and `undefined` for everything else.
	 */
	readonly syntheticConfig?: Record<string, unknown>;
}

/**
 * The fully-assembled config + the tool list, ready to drive the
 * verify probes or the harvest emitter.
 */
export interface IPluginTestBed {
	readonly config: IAssembledCliConfig['config'];
	readonly tools: readonly import('@delendai/core/public').IToolRegistration[];
	/**
	 * f00030-protect-verify-tools: prompts/skills counts surfaced so
	 * `verify:tools` can distinguish "plugin shipped no tools by
	 * design" (e.g. `prompts-pack`, `skills-pack` — they only contribute
	 * prompts/skills, no `server.registerTool()`) from "plugin failed to
	 * register tools" (a real regression). Without this, every
	 * prompts/skills-only plugin showed up as `(no-plugin-tools)` and
	 * failed the harness.
	 */
	readonly promptsCount: number;
	readonly skillsCount: number;
	/**
	 * Plugin load failures (x00105 S1). The bed used to drop these on
	 * the floor, which is exactly how verify:tools spent months
	 * reporting green while probing zero plugin-owned tools. Callers
	 * MUST surface a non-empty list as a failure.
	 */
	readonly loadErrors: readonly string[];
}

/**
 * Build the assembly deps (importer + readFile) and call
 * `assembleCliConfig`. Pure factory over its inputs.
 */
export const assemblePluginForTest = async (
	options: IPluginTestBedOptions,
): Promise<IPluginTestBed> => {
	const args = parseCliArgs(
		[
			`--plugins=${options.pluginName}`,
			`--workspace=${options.workspaceRoot}`,
			// The bed verifies a plugin's complete registration, including
			// tools hidden by the managed bootstrap surface. Native is
			// explicit here so this harness does not mistake exposure policy
			// for a plugin load failure.
			'--surface=native',
		],
		options.workspaceRoot,
	);

	const importer: IPluginImporter =
		options.importer ?? createLocalPluginImporter(options.workspaceRoot);

	const deps: IAssembleCliDeps = {
		import: (specifier: string) => importer(specifier),
		...(options.syntheticConfig !== undefined
			? {
					readFile: async (absolutePath: string) =>
						absolutePath.endsWith('delendai.config.json')
							? JSON.stringify(options.syntheticConfig)
							: undefined,
				}
			: {}),
	};

	const { config, loadResult } = await assembleCliConfig(args, deps);
	const tools = config.extraTools ?? [];
	return {
		config,
		tools,
		promptsCount: config.extraPrompts?.length ?? 0,
		skillsCount: loadResult.loaded.reduce(
			(total, entry) => total + (entry.registrations.skills?.length ?? 0),
			0,
		),
		loadErrors: loadResult.errors.map((error) => error.message),
	};
};
