/**
 * Shapes for `./publish-candidate.script`.
 *
 * Kept beside the behaviour rather than inside it so a spec can reason
 * about a publication without spawning git.
 */

/** What the checkout is offering to publish. */
export interface ICandidateContent {
	/** Paths that exist and will be written into the candidate's tree. */
	readonly written: readonly string[];
	/** Paths the integration branch has and the candidate deletes. */
	readonly removed: readonly string[];
	/**
	 * Paths that are absent from the checkout and were never on the
	 * integration branch either — a transient file, not a deletion.
	 * Reported so a publication is never silently different from what
	 * the author saw, and then ignored.
	 */
	readonly vanished: readonly string[];
}

/** Why a publication was refused, in terms the author can act on. */
export interface IPublicationRefusal {
	readonly code:
		| 'NOT_A_PUBLICATION_REF'
		| 'NOTHING_TO_PUBLISH'
		| 'SCOPE_VIOLATION'
		| 'PREFLIGHT_FAILED'
		/** The tree would be identical to the integration branch's. */
		| 'EMPTY_CANDIDATE'
		/**
		 * A claimed path moved on the integration branch after this
		 * checkout's base, and the working copy does not carry that change —
		 * so publishing it would silently revert whatever landed. Refused
		 * by comparing object ids, which is what makes a stale publication
		 * impossible rather than merely discouraged.
		 */
		| 'STALE_PATH'
		/** `--from-work-branch` named a branch outside the work namespace. */
		| 'NOT_A_WORK_BRANCH'
		/** The work branch does not exist locally or on the remote. */
		| 'UNKNOWN_WORK_BRANCH'
		/**
		 * The remote work branch has commits the local tip does not. Deleting
		 * it after publishing would lose them, so nothing is published.
		 */
		| 'WORK_BRANCH_AHEAD'
		/** The publication ref did not end up at the published commit. */
		| 'PUBLICATION_UNVERIFIED';
	readonly detail: readonly string[];
}

/** The outcome of a publish attempt. */
export type IPublicationOutcome =
	| {
			readonly kind: 'published';
			readonly ref: string;
			readonly commit: string;
			readonly content: ICandidateContent;
	  }
	| { readonly kind: 'refused'; readonly refusal: IPublicationRefusal };

/** One step of removing a published work branch. */
export interface ICleanupStep {
	/** What the step removes, for the report. */
	readonly label: string;
	/** Printed when the step is done. */
	readonly doneMessage: string;
	/** Performs the step; may throw. */
	readonly run: () => void;
	/**
	 * Whether the step's effect is in place, asked only when `run` threw:
	 * a delete can succeed on the remote and still exit non-zero.
	 */
	readonly isDone: () => boolean;
	/** The exact command that finishes the step by hand. */
	readonly remedy: string;
}

export interface ICleanupOutcome {
	readonly done: readonly string[];
	readonly remaining: ReadonlyArray<{
		readonly label: string;
		readonly reason: string;
		readonly remedy: string;
	}>;
}
