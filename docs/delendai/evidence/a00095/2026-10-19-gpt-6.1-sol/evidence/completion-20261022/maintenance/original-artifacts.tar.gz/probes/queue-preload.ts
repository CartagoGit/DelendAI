import { mock } from 'bun:test';
import { appendFileSync } from 'node:fs';
const root=process.env.AUDIT_PROBE_ROOT!;
const logPath=process.env.AUDIT_QUEUE_CALLS!;
const mode=process.env.AUDIT_CERT_MODE!;
const base='b'.repeat(40),head='a'.repeat(40);
let armed=false;
const pull=()=>({number:1,title:'owned fixture candidate',head:{ref:'pub/fixture',sha:head},base:{ref:'integration'},draft:false,auto_merge:armed?{}:null});
const run=(program:string,args:string[])=>{
 appendFileSync(logPath,JSON.stringify({program,args})+'\n');
 if(program!=='gh')throw Error('Blocked unexpected subprocess '+program);
 if(args[0]==='pr' && args.includes('--auto')){armed=true;return '';}
 if(args[0]!=='api')throw Error('Unmapped gh command '+args.join(' '));
 const p=args[1];
 if(p.includes('/pulls?'))return JSON.stringify([pull()]);
 if(p.endsWith('/pulls/1'))return JSON.stringify({mergeable_state:'clean'});
 if(p.includes('/check-runs?'))return JSON.stringify({check_runs:[{name:'required',conclusion:'success'}]});
 if(p.endsWith('/commits/integration'))return JSON.stringify({sha:base});
 if(p.includes('/workflows/ci.yml/runs?')){
  const sha=p.includes('head_sha='+base)?base:head;
  const runs=mode==='uncertified'?[]:[{head_sha:sha,event:'workflow_dispatch',status:mode==='pending'?'in_progress':'completed',conclusion:mode==='pending'?null:mode==='red'?'failure':'success'}];
  return JSON.stringify({workflow_runs:runs});
 }
 if(p.includes('/compare/'))return JSON.stringify({behind_by:0});
 if(p.includes('/actions/runs?'))return JSON.stringify({workflow_runs:[]});
 throw Error('Unmapped gh API '+p);
};
mock.module('node:child_process',()=>({execFileSync:run}));
mock.module('@delendai/core/public',()=>({resolveDevelopmentPolicy:()=>({branches:{integration:'integration',release:'release',publicationRefPrefix:'pub/'},integration:{mergeMethod:'merge',requiredChecks:['required']}})}));
mock.module(root+'/tools/scripts/lib/declared-branches.ts',()=>({mergeFlagFor:(m:string)=>'--'+m}));
mock.module(root+'/tools/scripts/lint/pr-head-shape.script.ts',()=>({isBranchModelMove:()=>false}));
mock.module(root+'/tools/scripts/forge/queue-acceptance.ts',()=>({queueAcceptance:(input:any)=>input.candidates.map((c:any)=>({number:c.number,headRef:c.headRef,accepted:true,why:'Owned level candidate: acceptance port fixture'}))}));
