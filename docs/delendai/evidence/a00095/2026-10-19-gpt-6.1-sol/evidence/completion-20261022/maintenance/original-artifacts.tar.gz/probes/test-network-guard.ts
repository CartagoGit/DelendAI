globalThis.fetch=async()=>{throw Error('Network fetch blocked by owned audit fixtures')};
