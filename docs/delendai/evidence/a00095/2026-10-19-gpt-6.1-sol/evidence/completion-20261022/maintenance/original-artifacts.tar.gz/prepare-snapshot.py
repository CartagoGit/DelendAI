"""Read-only Git extraction into this scratch directory, with local dependency reuse."""
import pathlib,subprocess,tarfile,io
r=pathlib.Path(__file__).resolve().parent;s=r/'test-snapshot'
repo=pathlib.Path('/home/cartago/_projects/delendai');sha='95841ce85b486112d049a6ad871d1612e4fcfd88'
if s.exists():raise SystemExit('Snapshot already exists; inspect it rather than overwriting evidence.')
s.mkdir()
names=subprocess.check_output(['git','-C',str(repo),'ls-tree','--name-only',sha],text=True).splitlines()
selected=[x for x in names if x in ['packages','plugins','tools','config','.github','package.json','bun.lock','delendai.config.json','vitest.shared.ts'] or x.startswith('tsconfig')]
b=subprocess.check_output(['git','-C',str(repo),'archive',sha,*selected]);tarfile.open(fileobj=io.BytesIO(b)).extractall(s,filter='data')
(s/'node_modules').symlink_to(repo/'node_modules',target_is_directory=True)
print(str(s))
