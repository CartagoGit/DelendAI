#!/usr/bin/env bun
/**
 * monorepo-paths.ts — single source of truth for the monorepo build /
 * dist layout.
 *
 * Why this module exists
 * ----------------------
 * The repo publishes and ships artefacts from three different layouts,
 * and confusing them silently breaks consumers:
 *
 *   1. `packages/[name]/dist/`  +  `plugins/[name]/dist/` — per-package
 *      publishable surfaces. Each `package.json#exports` points there.
 *      Intentionally TRACKED in git. Renaming/moving this would break
 *      every downstream consumer.
 *
 *   2. `build/<group>/<name>/` — monorepo-wide bundler/compiler outputs.
 *      NEVER TRACKED. Examples today: `build/docs-api/` (typedoc),
 *      `build/apps/web/` (Astro).
 *
 *   3. `dist/<group>/<name>/<version>/<artifact>` — legacy monorepo-wide
 *      distributable artefacts. NEVER TRACKED. New build pipelines should
 *      place versioned artefacts under `build/` instead.
 *
 * Any script, package.json script, or CI workflow that needs to compute
 * one of these paths MUST import from this module. Hard-coding
 * `../../dist/apps/...` or `'build/docs-api'` in scattered places is
 * exactly the drift this module prevents — when we add a new app/plugin/
 * package, you just call `buildDir('apps', 'my-new-app')` and the layout
 * follows the convention.
 *
 * Invariants
 * ----------
 * - `repoRoot()` returns the worktree the caller is currently in
 *   (`git rev-parse --show-toplevel`), NOT the symlink/real path of this
 *   file. That matters when the script runs from a linked worktree.
 * - All returned paths are absolute.
 * - Path segments passed in are validated to be lowercase, kebab-safe,
 *   and free of `..` traversal. The module does not silently allow
 *   malformed names because a typo in `extensions/vscode` is exactly the
 *   class of bug we're trying to prevent.
 */
import { readFileSync } from 'node:fs';
import { dirname, join, sep } from 'node:path';
import { DEFAULT_CORE_PATHS } from '@delendai/core/cli';

import { repoRoot } from './repo-root';

/** Groups the monorepo recognises, in the order they appear in the tree. */
export type MonorepoGroup = 'apps' | 'plugins' | 'packages' | 'extensions';

const VALID_GROUPS = new Set<MonorepoGroup>([
	'apps',
	'plugins',
	'packages',
	'extensions',
]);

/** Anything that can live in one of those groups. */
export type MonorepoArtifact = string;

/**
 * Names that are safe to embed in a path: lowercase letters, digits,
 * hyphens, dots, underscores, plus signs (npm allows a small set). We
 * reject `/`, `\`, `..`, `~`, leading dots, and any uppercase so that
 * a typo cannot silently write to `apps/Web/dist/`.
 */
const NAME_PATTERN = /^[a-z0-9][a-z0-9._+-]*$/;

const assertSafeName = (kind: string, name: string): void => {
	if (typeof name !== 'string' || name.length === 0) {
		throw new Error(
			`${kind} must be a non-empty string, got ${JSON.stringify(name)}`,
		);
	}
	if (!NAME_PATTERN.test(name)) {
		throw new Error(
			`${kind} ${JSON.stringify(name)} is not a valid monorepo name. ` +
				`Allowed: lowercase letters, digits, hyphens, dots, underscores, plus signs, ` +
				`must not start with a dot. (Tip: don't pass a path — pass just the leaf name.)`,
		);
	}
	if (name.includes('..') || name.includes('/') || name.includes('\\')) {
		throw new Error(
			`${kind} ${JSON.stringify(name)} contains path traversal.`,
		);
	}
};

/**
 * Validate a group name and return it typed as `MonorepoGroup`.
 *
 * Implemented as a plain value-returning function (not a TS `asserts`
 * predicate) so the call sites stay compatible with TypeScript 6+'s
 * stricter `asserts`-call-target rules (TS2775), which would
 * otherwise require the `group` argument to be re-annotated at every
 * call site. The runtime behaviour — throw on an unknown name — is
 * identical.
 */
const assertSafeGroup = (group: string): MonorepoGroup => {
	if (!VALID_GROUPS.has(group as MonorepoGroup)) {
		throw new Error(
			`Unknown monorepo group ${JSON.stringify(group)}. ` +
				`Expected one of: ${[...VALID_GROUPS].join(', ')}.`,
		);
	}
	return group as MonorepoGroup;
};

/**
 * Re-exported from `./repo-root`, which owns the implementation.
 *
 * The split exists so callers that need ONLY the worktree root — a
 * governance guard running in an environment with no `node_modules`, for
 * one — do not drag in this module's `@delendai/core/public` import and
 * with it the whole MCP SDK. See `repo-root.ts` for the full rationale.
 * This module remains the single place the layout is defined, and
 * remains a valid import site for `repoRoot`.
 */
export { repoRoot };

/**
 * Absolute path to the per-package build output (a directory that lives
 * inside the package and is INTENTIONALLY tracked, because its
 * `package.json#exports` points there). This is the layout that
 * downstream consumers import from.
 *
 *   packages/<name>/dist
 *   plugins/<name>/dist
 *
 * Apps do NOT use this layout — their build output goes to the
 * monorepo-wide `buildDir('apps', <name>)`.
 */
export const packageBuildDir = (group: MonorepoGroup, name: string): string => {
	// `assertSafeGroup` is now value-returning (TS 6+ TS2775 compatibility);
	// discard the narrowed value because the parameter is already typed.
	void assertSafeGroup(group);
	assertSafeName('name', name);
	return join(repoRoot(), group, name, 'dist');
};

/**
 * Absolute path to the monorepo-wide build output (a directory that is
 * NEVER tracked). Examples: `build/docs-api/`, `build/apps/web/`.
 */
export const buildDir = (group: MonorepoGroup, name: string): string => {
	// `assertSafeGroup` is now value-returning (TS 6+ TS2775 compatibility);
	// discard the narrowed value because the parameter is already typed.
	void assertSafeGroup(group);
	assertSafeName('name', name);
	return join(repoRoot(), 'build', group, name);
};

/** Absolute path to a versioned artefact directory under `build/`. */
export const buildVersionDir = (
	group: MonorepoGroup,
	name: string,
	version: string,
): string => {
	void assertSafeGroup(group);
	assertSafeName('name', name);
	if (typeof version !== 'string' || version.length === 0) {
		throw new Error(
			`version must be a non-empty string, got ${JSON.stringify(version)}`,
		);
	}
	if (!/^[a-zA-Z0-9][a-zA-Z0-9._+-]*$/.test(version)) {
		throw new Error(
			`version ${JSON.stringify(version)} is not a valid semver-shaped string.`,
		);
	}
	return join(buildDir(group, name), version);
};

/** Absolute path to one versioned build artefact under `build/`. */
export const buildArtifactPath = (
	group: MonorepoGroup,
	name: string,
	version: string,
	artifact: string,
): string => {
	if (
		typeof artifact !== 'string' ||
		artifact.length === 0 ||
		artifact.includes('/') ||
		artifact.includes('\\') ||
		artifact.includes('..')
	) {
		throw new Error(
			`artifact ${JSON.stringify(artifact)} contains path traversal or is empty.`,
		);
	}
	return join(buildVersionDir(group, name, version), artifact);
};

/**
 * Absolute path to the monorepo-wide distributable directory. The version
 * is preserved in the path so historical artefacts can be inspected
 * locally without overwriting each other.
 *
 *   dist/<group>/<name>/<version>/
 */
export const distVersionDir = (
	group: MonorepoGroup,
	name: string,
	version: string,
): string => {
	// `assertSafeGroup` is now value-returning (TS 6+ TS2775 compatibility);
	// discard the narrowed value because the parameter is already typed.
	void assertSafeGroup(group);
	assertSafeName('name', name);
	if (typeof version !== 'string' || version.length === 0) {
		throw new Error(
			`version must be a non-empty string, got ${JSON.stringify(version)}`,
		);
	}
	if (!/^[a-zA-Z0-9][a-zA-Z0-9._+-]*$/.test(version)) {
		throw new Error(
			`version ${JSON.stringify(version)} is not a valid semver-shaped string.`,
		);
	}
	return join(repoRoot(), 'dist', group, name, version);
};

/**
 * Absolute path to a single distributable artefact under the version dir.
 *
 *   dist/<group>/<name>/<version>/<artifact>
 */
export const distArtifactPath = (
	group: MonorepoGroup,
	name: string,
	version: string,
	artifact: string,
): string => {
	if (typeof artifact !== 'string' || artifact.length === 0) {
		throw new Error(`artifact must be a non-empty string`);
	}
	if (
		artifact.includes('/') ||
		artifact.includes('\\') ||
		artifact.includes('..')
	) {
		throw new Error(
			`artifact ${JSON.stringify(artifact)} contains path traversal.`,
		);
	}
	return join(distVersionDir(group, name, version), artifact);
};

/**
 * A name that lives directly under `build/` without a group prefix
 * (e.g. `build/docs-api/`). Use this for top-level tooling outputs that
 * don't belong to any particular package.
 */
export const buildTopLevel = (name: string): string => {
	assertSafeName('top-level build name', name);
	return join(repoRoot(), 'build', name);
};

/**
 * The single canonical cache root for this repo: ALWAYS the root
 * `<repo-root>/.cache/delendai` (f00065 S2). There is no per-folder,
 * per-app, or per-package cache — every runtime-generated delendai state
 * lives under this one directory.
 *
 * The workspace-relative segment (`.cache/delendai`) is reused from core's
 * `DEFAULT_CORE_PATHS.cacheDir` so the path is defined exactly once across the
 * runtime engine and the tooling, the same single-source-of-truth pattern as
 * `skill-paths.ts`. Tools that need to read/clean the cache resolve it here;
 * the runtime engine resolves it from `DEFAULT_CORE_PATHS` joined to its
 * workspace. The `check-cache` lint guarantees no stray `.cache` ever appears
 * outside this root.
 */
export const cacheRoot = (): string =>
	join(repoRoot(), ...DEFAULT_CORE_PATHS.cacheDir.split('/'));

/** Workspace-relative canonical cache dir (`.cache/delendai`). */
export const CACHE_DIR_REL = DEFAULT_CORE_PATHS.cacheDir;

/**
 * Stable well-known names. These are the few directories the rest of the
 * repo references by name. Every other build / dist path SHOULD be
 * derived from the helpers above so it survives renames.
 */
export const WELL_KNOWN = {
	/** typedoc output, served at /api/ by Astro via a symlink. */
	docsApi: () => buildTopLevel('docs-api'),
	/** Astro static site output, served by GitHub Pages. */
	webApp: () => buildDir('apps', 'web'),
	/** VS Code extension build output. */
	vscode: () => buildDir('extensions', 'vscode'),
	/** VS Code packaged .vsix output under the canonical build tree. The flat `name` in
	 *  `extensions/vscode/package.json` is kept as `delendai-vscode`
	 *  because `vsce` rejects scoped names; the `displayName` is the
	 *  new `@delendai/extension-vscode` for users. The packaging
	 *  script reads `manifest.name` to compute this directly, so this
	 *  helper is the second-source-of-truth for tests + documentation. */
	vscodeVsix: (version: string) =>
		buildArtifactPath(
			'extensions',
			'vscode',
			version,
			`delendai-vscode-${version}.vsix`,
		),
} as const;

/**
 * Compute the relative symlink target from the symlink path `linkDir` to
 * `targetDir`. The returned string is intended to be stored as the body
 * of a symlink at `linkDir`; it is interpreted relative to
 * `dirname(linkDir)`.
 *
 * We avoid Node's `path.relative` because it returns paths like
 * `../../../foo` even when both endpoints share a common ancestor at
 * the FS root (the extra `../` escapes the mount). This implementation
 * climbs manually through `repoRoot()`.
 */
export const relativeFrom = (linkDir: string, targetDir: string): string => {
	const root = repoRoot();
	// Count the climb from the symlink's PARENT (not from the symlink
	// itself) up to the repo root. The symlink lives at `linkDir`; the
	// symlink target is interpreted relative to `dirname(linkDir)`.
	const linkParentParts = dirname(linkDir)
		.split(sep)
		.filter((p) => p.length > 0);
	const rootParts = root.split(sep).filter((p) => p.length > 0);
	const climb = linkParentParts.length - rootParts.length;
	if (targetDir === root) {
		if (climb <= 0) return '.';
		if (climb === 1) return '..';
		return '../'.repeat(climb).replace(/\/+$/, '');
	}
	if (targetDir.startsWith(root + sep)) {
		const descend = targetDir.slice(root.length + 1);
		if (climb <= 0) return descend;
		return '../'.repeat(climb) + descend;
	}
	// Target lives outside the repo — fall back to absolute, callers
	// usually want the absolute path here anyway.
	return targetDir;
};

/**
 * Validate a candidate package name against the same rules used by
 * `assertSafeName`, but as a one-shot predicate (no throw). Useful in
 * scaffolders / linters that want to report all errors instead of
 * failing on the first one.
 */
export const isSafeName = (name: string): boolean => {
	if (typeof name !== 'string' || name.length === 0) return false;
	if (!NAME_PATTERN.test(name)) return false;
	if (name.includes('..') || name.includes('/') || name.includes('\\'))
		return false;
	return true;
};

/**
 * Validate a candidate group name. Useful for the same reason as
 * `isSafeName`.
 */
export const isSafeGroup = (group: string): group is MonorepoGroup =>
	VALID_GROUPS.has(group as MonorepoGroup);

/**
 * Read a JSON file and return its parsed contents. Used by packaging /
 * scaffolding scripts to pull the `version` from each app's
 * `package.json` without inventing a config format. Re-throws with a
 * path-qualified message so failures are easy to debug.
 */
export const readJSON = <T = unknown>(path: string): T => {
	try {
		const raw = readFileSync(path, 'utf8');
		return JSON.parse(raw) as T;
	} catch (err) {
		const reason = err instanceof Error ? err.message : String(err);
		throw new Error(`Could not read JSON at ${path}: ${reason}`);
	}
};
