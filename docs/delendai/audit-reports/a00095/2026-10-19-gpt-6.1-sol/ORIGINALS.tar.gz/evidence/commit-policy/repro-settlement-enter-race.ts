import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

import { DEFAULT_BRANCH_POLICY } from '@delendai/commit-policy/lib/contracts/branch';
import { createCommitPolicyEngine } from '@delendai/commit-policy/lib/engine';
import { createSettlementTool } from '@delendai/commit-policy/lib/tools/settlement-tool';
import { createWorkerRegistry } from '@delendai/commit-policy/lib/settlement/worker.registry';
import type { IGitRunner } from '@delendai/core/contracts';
import type { ICommitPolicyOptions } from '@delendai/commit-policy/lib/contracts/options';

const root = process.cwd();
const workspace = process.argv[3];
if (workspace === undefined) throw new Error('workspace arg required');
const rendezvous = join(workspace, 'rendezvous');
const stateRel = '.cache/delendai/commit-policy/settlement.json';
const lockPath = join(workspace, '.cache/delendai/agents.lock.json');
const waitFor = async (name: string): Promise<void> => {
	const path = join(rendezvous, name);
	for (let i = 0; i < 500; i += 1) {
		try {
			await readFile(path, 'utf8');
			return;
		} catch {
			await new Promise((resolve) => setTimeout(resolve, 10));
		}
	}
	throw new Error(`timed out waiting for ${name}`);
};
const signal = (name: string, value = 'ok'): Promise<void> =>
	writeFile(join(rendezvous, name), value);

if (process.argv[2] === 'enter') {
	const tool = createSettlementTool({
		workspaceRoot: workspace,
		fileRel: stateRel,
		liveWorkers: async () => {
			let live = false;
			try {
				const lock = JSON.parse(await readFile(lockPath, 'utf8')) as {
					in_flight?: unknown[];
				};
				live = (lock.in_flight?.length ?? 0) > 0;
			} catch {}
			await signal('worker-count-read', live ? '1' : '0');
			await waitFor('allow-enter');
			return live ? 1 : 0;
		},
	});
	const result = await tool.enter({});
	await signal('enter-result', JSON.stringify(result));
	process.exit(0);
}

if (process.argv[2] === 'slice') {
	const registry = createWorkerRegistry({
		workspaceRoot: workspace,
		fileRel: stateRel,
	});
	await waitFor('worker-count-read');
	await mkdir(join(workspace, '.cache/delendai'), { recursive: true });
	await writeFile(
		lockPath,
		JSON.stringify({
			in_flight: [
				{
					task_id: 'task-race',
					agent: 'agent-race',
					ownership: ['src/race.ts'],
					last_seen: new Date().toISOString(),
					host: 'audit-host',
					pid: process.pid,
				},
			],
		}),
	);

	const policy: ICommitPolicyOptions = {
		gitTimeoutMs: 1_000,
		commit: {
			enabled: true,
			requireConventional: true,
			autoScopeFromProposal: true,
			refuseWhenDisabled: true,
		},
		stash: { enabled: false },
		identity: { mode: 'global' },
		audit: { trailer: 'none', agentFormat: '${host}/${model}' },
		cadence: {
			triggers: [],
			sliceScoping: true,
			allowForeignChanges: false,
			quietPeriodMs: 0,
		},
		push: {
			enabled: false,
			onCommit: false,
			force: 'with-lease',
			protectedBranches: ['main'],
		},
	};
	const calls: string[] = [];
	const run: IGitRunner = async (args) => {
		calls.push(args.join(' '));
		if (args.join(' ') === 'rev-parse --abbrev-ref HEAD') {
			return { ok: true, output: 'feature/race\n' };
		}
		return {
			ok: false,
			output: '',
			reason: 'stopped after proving the settlement gate passed',
		};
	};
	const engine = createCommitPolicyEngine({
		driver: {
			run,
			policy,
			identityCtx: { run, envVars: Object.freeze({}) },
			auditAgent: null,
		},
		branchPolicy: DEFAULT_BRANCH_POLICY,
		settlementRead: async () => {
			const phase = (await registry.read()).phase;
			await signal('engine-gate-read', phase);
			await waitFor('release-engine');
			return phase;
		},
	});
	const resultPromise = engine.handle({
		kind: 'slice',
		proposalId: 'f12345-race',
		sliceId: 'S1',
		files: ['src/race.ts'],
		eventId: 'race-event',
	});
	await waitFor('engine-gate-read');
	await signal('allow-enter');
	await waitFor('enter-result');
	const phaseAfterEnter = (await registry.read()).phase;
	await signal('release-engine');
	const result = await resultPromise;
	await signal(
		'slice-result',
		JSON.stringify({ phaseAfterEnter, result, calls }),
	);
	process.exit(0);
}

if (process.argv[2] === 'parent') {
	await mkdir(rendezvous, { recursive: true });
	const self = process.argv[1];
	if (self === undefined) throw new Error('script path required');
	const runChild = (role: string) =>
		Bun.spawn([process.execPath, self, role, workspace], {
			cwd: root,
			stdout: 'inherit',
			stderr: 'inherit',
		});
	const entering = runChild('enter');
	const slicing = runChild('slice');
	const [enterExit, sliceExit] = await Promise.all([
		entering.exited,
		slicing.exited,
	]);
	const enter = await readFile(join(rendezvous, 'enter-result'), 'utf8');
	const slice = await readFile(join(rendezvous, 'slice-result'), 'utf8');
	console.log(
		JSON.stringify(
			{
				processes: 2,
				enterExit,
				sliceExit,
				enter: JSON.parse(enter),
				observation: JSON.parse(slice),
			},
			null,
			2,
		),
	);
	process.exitCode = enterExit === 0 && sliceExit === 0 ? 0 : 1;
}
